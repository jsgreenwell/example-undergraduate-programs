package sample;

import javafx.scene.control.Label;

public class Controller {
  public Label helloWorld;

  public void sayHello() {
    helloWorld.setText("Hello World!");
  }
}
