package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
/* This is only meant to be run to check that JavaFX is working.
   It is really just the basic, default setup with a button & label added.
   If you cannot get your code to run without errors - you would run this
   and let me know what errors it gives so we can look at your setup.

   You can then just use this as a base/template with JavaFX in the course.
 */
  @Override
  public void start(Stage primaryStage) throws Exception{
    Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
    primaryStage.setTitle("Hello World");
    primaryStage.setScene(new Scene(root, 300, 275));
    primaryStage.show();
  }


  public static void main(String[] args) {
    launch(args);
  }
}
